import 'package:flutter_test/flutter_test.dart';
import 'package:recipath/widgets/generic/search_text.dart';
import 'package:recipath/widgets/screens/shopping_screen/shopping_progress.dart';

void main() {
  test('counts regular and quick list rows independently of grouping', () {
    final progress = countShoppingProgress([false, false, true, false, true]);
    expect(progress, (checked: 2, total: 5));
    expect(countShoppingProgress(const []), (checked: 0, total: 0));
  });

  test('uses the same case-insensitive substring match after indexing', () {
    final key = indexSearchText('Olive Oil – LÉMON');
    expect(matchesSearchText(key, prepareSearchQuery('OIL')), isTrue);
    expect(matchesSearchText(key, prepareSearchQuery('lémon')), isTrue);
    expect(matchesSearchText(key, prepareSearchQuery('lemons')), isFalse);
    expect(matchesSearchText(key, prepareSearchQuery('')), isTrue);
  });
}
