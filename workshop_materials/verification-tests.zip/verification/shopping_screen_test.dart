import 'dart:io';

import 'package:drift/drift.dart' show Value;
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:recipath/drift/database.dart';
import 'package:recipath/widgets/generic/search_text_field.dart';

import '../../tool/workshop_main.dart';

final _progress = find.byKey(const ValueKey('shopping-progress-label'));
final _remaining = find.byWidgetPredicate(
  (widget) => widget is IconButton && widget.tooltip == 'Only remaining',
);

void main() {
  testWidgets('real shopping route counts unique rows and updates on check', (
    tester,
  ) async {
    final world = await _open(tester);
    expect(tester.widget<Text>(_progress).data, '1 of 6 checked · 5 left');

    await _write(tester, () {
      return (world.db.update(world.db.shoppingTable)
            ..where((row) => row.id.equals('shopping-0')))
          .write(const ShoppingTableCompanion(done: Value(true)));
    });
    expect(tester.widget<Text>(_progress).data, '2 of 6 checked · 4 left');

    await tester.tap(_remaining);
    await tester.pumpAndSettle();
    expect(tester.widget<IconButton>(_remaining).isSelected, isTrue);
    expect(tester.widget<Text>(_progress).data, '2 of 6 checked · 4 left');

    expect(tester.takeException(), isNull);
    await _unmount(tester);
  }, timeout: const Timeout(Duration(seconds: 25)));

  testWidgets('an all-checked list has a reversible completion state', (
    tester,
  ) async {
    await _open(tester, allChecked: true);
    await tester.tap(_remaining);
    await tester.pumpAndSettle();
    expect(find.text('All items checked'), findsOneWidget);
    expect(tester.widget<Text>(_progress).data, '6 of 6 checked · 0 left');

    await tester.tap(find.text('Show all items'));
    await tester.pumpAndSettle();
    expect(find.text('All items checked'), findsNothing);
    expect(tester.widget<IconButton>(_remaining).isSelected, isFalse);
    expect(tester.takeException(), isNull);
    await _unmount(tester);
  }, timeout: const Timeout(Duration(seconds: 25)));

  testWidgets('a search miss keeps the global count and is not completion', (
    tester,
  ) async {
    await _open(tester);
    final search = find.descendant(
      of: find.byType(SearchTextField),
      matching: find.byType(EditableText),
    );
    await tester.enterText(search, 'no-such-product-413');
    await tester.pumpAndSettle();

    expect(tester.widget<Text>(_progress).data, '1 of 6 checked · 5 left');
    expect(find.text('All items checked'), findsNothing);
    expect(tester.takeException(), isNull);
    await _unmount(tester);
  });
}

Future<({Widget app, AppDatabase db, GoRouter router, Directory directory})>
_open(WidgetTester tester, {bool allChecked = false}) async {
  final previousPaths = PathProviderPlatform.instance;
  final result = (await tester.runAsync(
    () => createShoppingWorkshop(stress: false, allChecked: allChecked),
  ))!;
  addTearDown(() async {
    result.router.dispose();
    await result.db.close();
    PathProviderPlatform.instance = previousPaths;
  });
  await tester.pumpWidget(result.app);
  for (var retry = 0; retry < 30 && !tester.any(_progress); retry++) {
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 30)),
    );
    await tester.pump(const Duration(milliseconds: 30));
  }
  await tester.pumpAndSettle();
  return result;
}

Future<void> _write(
  WidgetTester tester,
  Future<void> Function() operation,
) async {
  await tester.runAsync(() async {
    await operation();
    await Future<void>.delayed(const Duration(milliseconds: 70));
  });
  for (var i = 0; i < 5; i++) {
    await tester.pump(const Duration(milliseconds: 50));
  }
  await tester.pumpAndSettle();
}

Future<void> _unmount(WidgetTester tester) async {
  await tester.pumpWidget(const SizedBox.shrink());
  await tester.pump(const Duration(milliseconds: 100));
}
